# 世界编辑器深度汉化包 v1.0.2

BeamNG.drive 世界编辑器（World Editor）简体中文汉化，运行时替换，不修改游戏原文件。

## 安装
1. 把本 zip 放入 `.../BeamNG.drive/0.xx/mods/`（或游戏内 模组管理器 → 拖入）
2. 重启游戏
3. 按 F11 进入世界编辑器，界面即为中文

## 特性
- 6500+ 条界面文本翻译：菜单、工具面板、检查器字段、提示语、快捷键说明
- 采用 `中文##英文原文` 标签方案，控件 ID 保持唯一，不会串号
- 纯文本接口不追加 ##，不会出现多余符号；缺中文字形的字体自动跳过，不出现乱码
- 翻译结果缓存，对帧率无可测影响
- 卸载即恢复英文；控制台可随时开关：
  `extensions.editor_zhcnLocalization.setEnabled(false)`

## 结构
```
lua/ge/extensions/editor/zhcnLocalization.lua   主加载点：编辑器启动时自动扫描加载
lua/ge/extensions/zhcn/dictionary.lua           词表（可自行增补）
scripts/modScript.lua                           备用加载入口（Unpacked 安装时生效）
mod_info/ZHCNEditorLoc/info.json                模组信息
```

## 自行增补词条
编辑 `dictionary.lua` 的 `M.words`，加上 `['英文原文'] = '中文',`，
然后在游戏控制台执行 `extensions.editor_zhcnLocalization.reload()` 即可热更新。

## 已知边界
- 菜单栏「文件/编辑/视角/对象/视图/窗口/帮助」来自游戏内置语言包，不是本 mod
- 车辆名、关卡名、材质名等数据内容不翻译
- 少数使用 `cairo_regular_medium` 等无中文字形字体的标题保持英文，避免出现「????」
- 动态拼接串（含路径的如 `Level: /levels/...`）按前缀规则翻译
